// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "UObject/NoExportTypes.h"
#include "Spawnable_Mesh_Collection.generated.h"

/**
 * 
 */
UCLASS()
class SHADERWORLD_API USpawnable_Mesh_Collection : public UObject
{
	GENERATED_BODY()
	
};